import React, { Component } from 'react';
import axios from 'axios';
import { Redirect } from "react-router-dom";
import '../../App.css';
export default class List extends Component {

    constructor(props) {
        super(props);
        this.state = {
            isError: {
                res: false,
                message: ""
            },
            productList: [],
            redirect: false
        };
    }

    componentWillMount() {
        if (!window.localStorage.getItem('user')) {
            this.setState({redirect: true});
        }
    }

    async componentDidMount() {
        await axios.get('http://localhost:9000/api/product')
        .then(function (res) {
            if (res.status === 200) {
                this.setState({productList: res.data});
            } else {
                alert('No data'); 
            }
        }.bind(this))
        .catch(function (error) {
            // handle error
            console.log(error);
        });
    }

    render() {
        const { redirect } = this.state;

        if (redirect) {
            return <Redirect to='/login'/>;
        }

        let loopProduct = [];
        let productList = this.state.productList;
        let i = 0, index = 0;
        for (i in productList) {
            index++;
            loopProduct.push(                        
                                <tr key={i}>
                                    <th>{index}</th>
                                    <td>{productList[i].name}</td>
                                    <td>{productList[i].price.toLocaleString('vi')}</td>
                                    <td>{productList[i].quantity}</td>
                                    <td>{productList[i].description}</td>
                                </tr>
                            );
        }

        return (
            <div className="container">
                <h1>List Product</h1>
                <table className="table">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Product Name</th>
                            <th scope="col">Price</th>
                            <th scope="col">Quantity</th>
                            <th scope="col">Description</th>
                        </tr>
                    </thead>
                    <tbody>
                        {loopProduct}
                    </tbody>
                </table>
            </div>
        );
    }
}