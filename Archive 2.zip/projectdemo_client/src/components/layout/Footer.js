import React, { Component } from './node_modules/react';

export default class Footer extends Component {
    render() {
        return (
            <h1>Ok Foooter</h1>
        );
    }
}