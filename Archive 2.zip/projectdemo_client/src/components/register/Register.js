import React, { Component } from 'react';
import axios from 'axios';
import { Redirect } from "react-router-dom";
import './register.css';

export default class Register extends Component {

    constructor(props) {
        super(props);
        this.state = {
            isError: {
                res: false,
                message: ""
            },
            redirect: false
        };
        this._register = this._register.bind(this);
    }

    async _register() {
        let name = this.refs.name.value;
        let tel = this.refs.phone.value;
        let password= this.refs.password.value;
        let confirm_password= this.refs.confirm_password.value;
        if (password !== confirm_password) {
            alert('Re-type password must be same value');
            return false;
        }
        const params = new URLSearchParams();
        let result = 0;
        params.append('name', name);
        params.append('tel', tel);
        params.append('password', password);
        await axios.post('http://localhost:9000/api/user/add', params,{
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            }
        })
        .then(function (res) {
           result = 1;
        })
        .catch(function (error) {
            // handle error
            console.log(error);
        });
        if (result === 1) {
            alert('Register successfuly')
            this.setState({redirect: true});
        } else {
            alert('error');
        }
    }

    render() {
        const { redirect } = this.state;

        if (redirect) {
            return <Redirect to='/login'/>;
        }

        return (
            <div className="signup-form">
                <h2>Register</h2>
                <div className="form-group">
                    <input type="text" className="form-control" name="name" ref="name" placeholder="Name" required="required"/>	
                </div>
                <div className="form-group">
                    <input type="text" className="form-control" name="tel" ref="phone" placeholder="Phone" required="required"/>
                </div>
		        <div className="form-group">
                    <input type="password" className="form-control" name="password" ref="password" placeholder="Password" required="required"/>
                </div>
		        <div className="form-group">
                    <input type="password" className="form-control" name="confirm_password" ref="confirm_password" placeholder="Confirm Password" required="required"/>
                </div>
                <div className="form-group">
                    <button type="submit" onClick={this._register} className="btn btn-success btn-lg btn-block">Register Now</button>
                </div>
            </div>
        );
    }
}

  