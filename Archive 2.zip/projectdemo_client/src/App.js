import React, { Component } from 'react';
import Login from './components/login/Login';
import 'bootstrap/dist/css/bootstrap.min.css';
import './index.css'


class App extends Component {
  render() {
    return (
      <Login />
    );
  }
}

export default App;
