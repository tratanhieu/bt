// Import user model
Product = require('../models//productModel');

// Handle event
exports.getAll = function (req, res) {
    Product.get(null, function (err, products) {
        if (err) {
            console.log(err)
            res.status(400).json(err);
            return;
        }
        res.status(200).json(products);
    });
};
