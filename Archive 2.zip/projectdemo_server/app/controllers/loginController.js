// Import user model
User = require('../models//userModel');

// Handle login
exports.login = function (req, res) {
    User.login(req.body, function (err, user) {
        if (err) {
            res.status(400).json(err);
            return;
        }
        res.status(200).json(user);
    });
};