var db = require("../../database.js");

exports.get = function(id, callback) {
    var sql = "select * from products"
    var params = []
    if (id) {
        var sql = "select * from products"
        var params = [id]
    }

    db.all(sql, params, (err, row) => {
        if (err) {
            callback(err);
            return;
        }

        callback(null, row);
        return;
    });
}