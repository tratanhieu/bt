let router = require('express').Router();
var productController = require('../controllers/productController');

router.get('/', productController.getAll);

// Export API routes
module.exports = router;